function el(tag, text, className) { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; }
function textareaSelection(content,start,end,value) {
  if(typeof content!=='string'||typeof value!=='string'||!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||end<start||end>content.length)return null;
  // Native textarea.value folds CRLF and bare CR to LF. Saved revisions and
  // source offsets still describe the exact raw saved string.
  if(content.replace(/\r\n?/g,'\n')!==value)return null;
  const interior=index=>{if(index===0||index===content.length)return false;const a=content.charCodeAt(index-1),b=content.charCodeAt(index);return a===13&&b===10||a>=0xd800&&a<=0xdbff&&b>=0xdc00&&b<=0xdfff;};
  if(interior(start)||interior(end))return null;
  let normalizedStart=start,normalizedEnd=end;
  for(let i=0;i<end;i++)if(content.charCodeAt(i)===13&&content.charCodeAt(i+1)===10){if(i<start)normalizedStart--;normalizedEnd--;i++;}
  return {start:normalizedStart,end:normalizedEnd};
}
export async function render(root, api) {
  root.replaceChildren();
  const heading = el('h2', 'Workspace Editor'), description = el('p', 'Edit UTF-8 files, keep drafts in tabs, and compare exact minimal line edits.', 'muted');
  const state = el('p', 'Loading files…', 'status'); state.setAttribute('role', 'status');
  const controls = el('div', undefined, 'row'), pathInput = el('input'); pathInput.placeholder = 'folder/file.txt'; pathInput.setAttribute('aria-label', 'Relative file path');
  const openButton = el('button', 'Open file', 'button'), createButton = el('button', 'New file', 'button'), refreshButton = el('button', 'Refresh files', 'button');
  controls.append(pathInput, openButton, createButton, refreshButton);
  const files = el('div', undefined, 'card'), tabs = el('div', undefined, 'row'), pane = el('div', undefined, 'card');
  const editor = el('textarea'); editor.rows = 22; editor.spellcheck = false; editor.style.fontFamily = 'monospace'; editor.style.tabSize = '2'; editor.setAttribute('aria-label', 'File contents');
  const actions = el('div', undefined, 'row'), saveButton = el('button', 'Save file', 'button'), diffButton = el('button', 'Compare with saved version', 'button'), closeButton = el('button', 'Close tab', 'button');
  actions.append(saveButton, diffButton, closeButton);
  const findControls = el('div', undefined, 'row'), findInput = el('input'), replaceInput = el('input'), findButton = el('button', 'Find next', 'button'), replaceButton = el('button', 'Replace all', 'button');
  findInput.placeholder = 'Find literal text'; findInput.setAttribute('aria-label', 'Find literal text'); replaceInput.placeholder = 'Replacement'; replaceInput.setAttribute('aria-label', 'Replacement');
  findControls.append(findInput, replaceInput, findButton, replaceButton);
  const difference = el('pre'); difference.style.whiteSpace = 'pre-wrap'; difference.setAttribute('aria-label', 'Line difference');
  const searchPanel=el('section',undefined,'card'),searchControls=el('div',undefined,'row'),searchQuery=el('input'),caseControl=el('label',' Match case'),searchCase=el('input'),searchButton=el('button','Search saved files','button'),searchState=el('p','Search saved files; unsaved drafts are retained in their tabs.','muted'),searchResults=el('div');
  const wordControl=el('label',' Whole word'),searchWord=el('input'),regexControl=el('label',' Regular expression'),searchRegex=el('input');
  searchWord.type=searchRegex.type='checkbox';searchWord.checked=searchRegex.checked=false;searchWord.setAttribute('aria-label','Whole word in workspace search');searchRegex.setAttribute('aria-label','Regular expression in workspace search');wordControl.prepend(searchWord);regexControl.prepend(searchRegex);
  searchQuery.placeholder='Text or single-line pattern across files';searchQuery.setAttribute('aria-label','Find in saved files');searchCase.type='checkbox';searchCase.checked=true;searchCase.setAttribute('aria-label','Match case in workspace search');caseControl.prepend(searchCase);searchState.setAttribute('role','status');searchResults.setAttribute('aria-label','Workspace search results');searchControls.append(searchQuery,caseControl,wordControl,regexControl,searchButton);searchPanel.append(el('h3','Search workspace'),searchControls,searchState,searchResults,el('p','Regular expressions use a bounded single-line Unicode engine. Rust/PCRE2 syntax and some empty-match behavior differ.','muted'));
  pane.append(tabs, editor, actions, findControls, difference); root.append(heading, description, controls, files, searchPanel, pane, state);
  const sourceControl = el('section', undefined, 'card'); sourceControl.append(el('h3', 'Git source control'));
  const gitState = el('p', 'Loading repository…', 'muted'), gitControls = el('div', undefined, 'row');
  const initializeGit = el('button', 'Initialize Git repository', 'button'), refreshGit = el('button', 'Refresh source control', 'button'); gitControls.append(initializeGit, refreshGit);
  const identityControls = el('div', undefined, 'row'), authorName = el('input'), authorEmail = el('input'), saveIdentity = el('button', 'Save commit identity', 'button');
  authorName.placeholder = 'Commit author name'; authorName.setAttribute('aria-label', 'Commit author name'); authorEmail.placeholder = 'Commit author email'; authorEmail.setAttribute('aria-label', 'Commit author email'); identityControls.append(authorName, authorEmail, saveIdentity);
  const changes = el('div'), gitActions = el('div', undefined, 'row'), stageAll = el('button', 'Stage saved changes', 'button'), workingDiff = el('button', 'Show working diff', 'button'), stagedDiff = el('button', 'Show staged diff', 'button'); gitActions.append(stageAll, workingDiff, stagedDiff);
  const commitControls = el('div', undefined, 'row'), commitMessage = el('textarea'), commit = el('button', 'Commit staged changes', 'button'); commitMessage.rows = 3; commitMessage.placeholder = 'Commit message'; commitMessage.setAttribute('aria-label', 'Commit message'); commitControls.append(commitMessage, commit);
  const branchControls = el('div', undefined, 'row'), newBranch = el('input'), createBranch = el('button', 'Create and switch branch', 'button'), branches = el('select'), switchBranch = el('button', 'Switch branch', 'button');
  newBranch.placeholder = 'New branch name'; newBranch.setAttribute('aria-label', 'New branch name'); branches.setAttribute('aria-label', 'Repository branch'); branchControls.append(newBranch, createBranch, branches, switchBranch);
  const gitPatch = el('pre'), history = el('div'); gitPatch.style.whiteSpace = 'pre-wrap'; gitPatch.setAttribute('aria-label', 'Git patch');
  sourceControl.append(gitState, gitControls, identityControls, changes, gitActions, commitControls, branchControls, gitPatch, history); root.insertBefore(sourceControl, state);
  const documents = new Map(); let active = null,mounted=true,searchGeneration=0,pendingSearch=null,openingGeneration=0;
  const document = () => documents.get(active);
  function updateTabs() {
    tabs.replaceChildren();
    for (const [name, item] of documents) {
      const button = el('button', `${name}${item.content !== item.saved ? ' •' : ''}`, 'button'); button.setAttribute('aria-pressed', String(name === active));
      button.onclick = () => { openingGeneration++;active = name; editor.value = item.content; difference.textContent = ''; updateTabs(); }; tabs.append(button);
    }
    editor.disabled = diffButton.disabled = closeButton.disabled = !active;
    saveButton.disabled = !active || document()?.saving === true;
  }
  async function run(operation) { try { await operation(); } catch (error) { state.textContent = error.message; } }
  let repository = null;
  function displayRepository(data) {
    repository = data; changes.replaceChildren(); history.replaceChildren(); branches.replaceChildren();
    gitState.textContent = data.initialized ? `${data.branch} · ${data.head ? data.head.slice(0, 12) : 'No commits yet'} · ${data.changes.length} changed files. Source control uses saved files; save drafts before staging.` : 'No repository in this application workspace. Initialize to track its saved files.';
    initializeGit.disabled = data.initialized;
    for (const button of [saveIdentity, stageAll, workingDiff, stagedDiff, commit, createBranch, switchBranch]) button.disabled = !data.initialized;
    if (!data.initialized) return;
    if (!authorName.value) authorName.value = data.identity.name;
    if (!authorEmail.value) authorEmail.value = data.identity.email;
    for (const branch of data.branches) { const option = el('option', branch); option.value = branch; option.selected = branch === data.branch; branches.append(option); }
    switchBranch.disabled = data.branches.length === 0;
    for (const item of data.changes) {
      const row = el('div', undefined, 'row'); row.append(el('span', `${item.index}${item.working} ${item.originalPath ? item.originalPath + ' → ' : ''}${item.path}${item.conflict ? ' · merge conflict' : ''}`));
      if (item.untracked || item.working !== ' ') { const button = el('button', `Stage ${item.path}`, 'button'); button.onclick = () => run(() => gitUpdate('gitStage', { paths: [item.path, ...(item.originalPath ? [item.originalPath] : [])] })); row.append(button); }
      if (!item.untracked && item.index !== ' ') { const button = el('button', `Unstage ${item.path}`, 'button'); button.onclick = () => run(() => gitUpdate('gitUnstage', { paths: [item.path, ...(item.originalPath ? [item.originalPath] : [])] })); row.append(button); }
      const view = el('button', `View ${item.path} diff`, 'button'); view.onclick = () => run(async () => { gitPatch.textContent = (await api('gitDiff', { paths: [item.path], staged: item.index !== ' ' && !item.untracked })).patch || 'No tracked text changes in this comparison.'; }); row.append(view); changes.append(row);
    }
    stageAll.disabled = !data.changes.some(item => item.untracked || item.working !== ' ');
    commit.disabled = !data.changes.some(item => !item.untracked && item.index !== ' ');
    history.append(el('h4', 'Recent commits'));
    for (const item of data.history) history.append(el('p', `${item.id.slice(0, 12)} · ${item.subject} · ${item.author} · ${item.authoredAt}`));
  }
  async function gitUpdate(action, input = {}) { displayRepository(await api(action, input)); state.textContent = 'Source control updated.'; }
  refreshGit.onclick = () => run(() => gitUpdate('gitStatus'));
  initializeGit.onclick = () => run(() => gitUpdate('gitInitialize'));
  saveIdentity.onclick = () => run(() => gitUpdate('gitIdentity', { name: authorName.value, email: authorEmail.value }));
  stageAll.onclick = () => run(() => gitUpdate('gitStage', { paths: repository.changes.filter(item => item.untracked || item.working !== ' ').flatMap(item => [item.path, ...(item.originalPath ? [item.originalPath] : [])]) }));
  workingDiff.onclick = () => run(async () => { gitPatch.textContent = (await api('gitDiff', {})).patch || 'No tracked working changes.'; });
  stagedDiff.onclick = () => run(async () => { gitPatch.textContent = (await api('gitDiff', { staged: true })).patch || 'No staged changes.'; });
  commit.onclick = () => run(async () => { await gitUpdate('gitCommit', { message: commitMessage.value }); commitMessage.value = ''; });
  async function switchWorkspace(action, name) {
    await gitUpdate(action, { name });
    for (const [file, item] of documents) if (item.content === item.saved) {
      try { const data = await api('read', { path: file }); Object.assign(item, data, { saved: data.content }); }
      catch { documents.delete(file); }
    }
    if (!documents.has(active)) active = documents.keys().next().value ?? null;
    editor.value = document()?.content ?? ''; updateTabs(); await refresh(); state.textContent = 'Branch changed. Saved tabs refreshed; unsaved drafts were retained.';
  }
  createBranch.onclick = () => run(() => switchWorkspace('gitBranch', newBranch.value));
  switchBranch.onclick = () => run(() => switchWorkspace('gitSwitch', branches.value));
  async function refresh() {
    const data = await api('list', {}); files.replaceChildren(el('h3', 'Workspace files'));
    if (!data.files.length) files.append(el('p', 'No files yet. Create your first file above.', 'muted'));
    for (const name of data.files) { const button = el('button', name, 'button'); button.onclick = () => run(() => open(name)); files.append(button); }
    if (data.truncated) files.append(el('p', 'Showing up to 1,000 files and 12 folder levels.', 'muted'));
    state.textContent = `Workspace: ${data.root}`;
  }
  async function open(name,searchContext=null) {
    const request=++openingGeneration;
    if(!mounted||(searchContext!==null&&searchContext!==searchGeneration))return false;
    if (documents.has(name)) { active = name; editor.value = document().content; updateTabs(); return true; }
    const data = await api('read', { path: name });if(!mounted||request!==openingGeneration||(searchContext!==null&&searchContext!==searchGeneration))return false;
    if(!documents.has(data.path))documents.set(data.path, { ...data, saved: data.content });active = data.path;editor.value=document().content;difference.textContent = ''; updateTabs(); state.textContent = `Opened ${data.path}.`;return true;
  }
  const invalidateSearch=()=>{searchGeneration++;searchResults.replaceChildren();searchState.textContent='Search options changed. Search again to refresh saved-file results.';};
  searchQuery.oninput=invalidateSearch;searchCase.onchange=searchWord.onchange=searchRegex.onchange=invalidateSearch;
  searchButton.onclick=async()=>{
    const request=++searchGeneration;pendingSearch=request;searchButton.disabled=true;searchResults.replaceChildren();searchState.textContent='Searching saved files…';
    try {
      const data=await api('search',{query:searchQuery.value,matchCase:searchCase.checked,wholeWord:searchWord.checked,useRegex:searchRegex.checked});
      if(!mounted||request!==searchGeneration)return;
      searchState.textContent=`${data.matches.length} matches in ${data.matchedFiles} files. ${data.searchedFiles} text files searched.${data.skipped.length?` ${data.skipped.length} files skipped.`:''}${data.truncated?` Results are incomplete (${data.limitReasons.join(', ')}).`:''}`;
      for(const match of data.matches){
        const row=el('div',undefined,'row'),button=el('button',`${match.path}:${match.line}:${match.column}`,'button');
        button.onclick=()=>run(async()=>{
          if(!mounted||request!==searchGeneration)return;
          if(!await open(match.path,request)||!mounted||request!==searchGeneration)return;
          const item=document();
          if(item.revision!==match.revision||item.content!==item.saved){state.textContent='The result describes a saved-file snapshot. Your current draft was retained; search again after saving to refresh positions.';return;}
          const selection=textareaSelection(item.content,match.start,match.end,editor.value);
          if(!selection){state.textContent='The saved result does not match the text shown or its positions. Save or reopen the file, then search again.';return;}
          editor.focus();editor.setSelectionRange(selection.start,selection.end);state.textContent=`Opened ${match.path}, line${match.line}, column${match.column}.`;
        });row.append(button,el('span',match.preview));searchResults.append(row);
      }
    }catch(error){if(mounted&&request===searchGeneration)searchState.textContent=error.message;}
    finally{if(pendingSearch===request){pendingSearch=null;if(mounted)searchButton.disabled=false;}}
  };
  openButton.onclick = () => run(() => open(pathInput.value));
  createButton.onclick = () => run(async () => {
    const name = pathInput.value.trim().replaceAll('\\', '/'); if (!name) throw new Error('Enter a file path first.');
    if (documents.has(name)) throw new Error('That file is already open.');
    openingGeneration++;documents.set(name, { path: name, content: '', saved: '', revision: null }); active = name; editor.value = ''; difference.textContent = ''; updateTabs(); state.textContent = 'New draft. Save creates the file; existing files are protected.';
  });
  refreshButton.onclick = () => run(refresh);
  editor.oninput = () => { if (document()) { document().content = editor.value; updateTabs(); } };
  async function save() {
    const item = document(); if (!mounted || !item) return;
    if (item.saving) { state.textContent = 'This file is still saving. Your current draft is retained.'; return; }
    const name = item.path, content = item.content, revision = item.revision;
    item.saving = true; updateTabs();
    try {
      const data = await api('save', { path: name, content, revision });
      if (!mounted || documents.get(name) !== item) return;
      // The response describes the captured write; later typing remains the current draft.
      item.saved = data.content; item.revision = data.revision; item.bytes = data.bytes;
      if (document() === item) state.textContent = `Saved ${data.path} (${data.bytes} bytes).${item.content !== item.saved ? ' Your newer draft is retained; save again to keep it.' : ''}`;
    } catch (error) {
      if (mounted && documents.get(name) === item && document() === item) state.textContent = error.message;
    } finally {
      item.saving = false;
      if (mounted && documents.get(name) === item) updateTabs();
    }
  }
  saveButton.onclick = () => run(save);
  diffButton.onclick = () => run(async () => { const item = document(); if (!item) return; const diff = await api('diff', { before: item.saved, after: item.content }); difference.textContent = `Minimal line edits: ${diff.cost} (${diff.deleted} removed, ${diff.inserted} added)\n` + diff.operations.map(op => `${op.type === 'insert' ? '+' : op.type === 'delete' ? '-' : ' '} ${op.text}`).join('\n'); state.textContent = 'Comparison complete.'; });
  closeButton.onclick = () => { const item = document(); if (!item || (item.content !== item.saved && !window.confirm('Discard this unsaved draft?'))) return; openingGeneration++;documents.delete(active); active = documents.keys().next().value ?? null; editor.value = document()?.content ?? ''; difference.textContent = ''; updateTabs(); };
  findButton.onclick = () => { if (!findInput.value) { state.textContent = 'Enter find text.'; return; } const start = editor.selectionEnd; let at = editor.value.indexOf(findInput.value, start); if (at < 0) at = editor.value.indexOf(findInput.value); if (at < 0) { state.textContent = 'No match.'; return; } editor.focus(); editor.setSelectionRange(at, at + findInput.value.length); state.textContent = `Found at character ${at + 1}.`; };
  replaceButton.onclick = () => run(async () => { const item = document(); if (!item) return; const result = await api('replace', { content: item.content, find: findInput.value, replacement: replaceInput.value }); item.content = editor.value = result.content; updateTabs(); state.textContent = `${result.count} replacements in this draft. Save to keep them.`; });
  editor.onkeydown = event => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') { event.preventDefault(); run(save); } if (event.key === 'Tab') { event.preventDefault(); const start = editor.selectionStart, end = editor.selectionEnd; editor.setRangeText('  ', start, end, 'end'); editor.dispatchEvent(new Event('input')); } };
  updateTabs(); await run(refresh); await run(() => gitUpdate('gitStatus'));
  return()=>{mounted=false;searchGeneration++;openingGeneration++;};
}
